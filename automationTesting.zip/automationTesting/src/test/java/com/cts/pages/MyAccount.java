package com.cts.pages;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class MyAccount<WebElement> {
	public static By clickOnmyAccountLoc= By.linkText("My Account");
	public static By searchLoc=By.id("s");
	public static By displayTextLoc=By.xpath("//p[text()='Sorry, nothing found.']");
	
//public WebDriver driver;

//public MyAccountPage(WebDriver d)
//{
//	driver=d;
//}

	public static  void MyAccount(WebDriver driver)
	{
	driver.findElement(clickOnmyAccountLoc).click();
	}
	
	public static   void search(WebDriver driver, String name)
	{
		
		driver.findElement(searchLoc).sendKeys(name);
		
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(searchLoc)).sendKeys(Keys.ENTER).build().perform();
		}
	public static String displaytext(WebDriver driver)
	{
		String displayData=driver.findElement(displayTextLoc).getText();
		return displayData;
	
	}
	
	
	

	
	
	
	
//	public static void search(WebDriver driver)
//	{
//		driver.findElement(searchLoc).click();
//		
//	}
	
	

	}



