package com.cts.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class LogoutAccount {
	public static By clickOnLogOutLoc = By.xpath("//a[text()='Logout']");
	public static By clickOnShopLoc=By.linkText("Shop");
	public static By ClickOnHtmlBookLoc=By.linkText("HTML");
	public static By sortingLoc=By.name("orderby");
	public static By selectBookLoc=By.xpath("//a[@data-product_id='181']");
	public static By clickOnJavaLoc=By.linkText("JavaScript");
	public static By sortingLoc1=By.name("orderby");
	public static By selectBookLoc1=By.xpath("//a[@data-product_id='165']");



	public static void clickOnLogOut(WebDriver driver)
	{
	driver.findElement(clickOnLogOutLoc).click();
	}
    public static void ClicokOnshop(WebDriver driver)
    {
    	driver.findElement(clickOnShopLoc).click();
    }
   public static String getCurrentTitle(WebDriver driver)
   {
	  String expectedTitle="Products-Automation Practice Site";
	   String actualTitle=driver.getTitle();
	   return actualTitle;
   }
    public static void clickOnHtmlBook(WebDriver driver)
    {
    	driver.findElement(ClickOnHtmlBookLoc).click();
    }
    public static String getPageTitle(WebDriver driver)
    {
 	  String expectedTitle="HTM-Automation Practice Site";
 	   String actualTitle=driver.getTitle();
 	   return actualTitle;
    }
    public static void sortBy(WebDriver driver, String sortBy ) //"Sort by price: high to low"
    {
    	WebElement sorting = driver.findElement(sortingLoc);
		Select sortByOrder = new Select(sorting);
		sortByOrder.selectByVisibleText(sortBy);

    }
    public static void selectBook(WebDriver driver)
    {
    	driver.findElement(selectBookLoc).click();
    }
    public static void clickOnJavaScript(WebDriver driver)
    {
    	 driver.findElement(clickOnJavaLoc).click();
    }
    public static void sorting(WebDriver driver, String sortingBy)
    {
    	WebElement sorting1 = driver.findElement(sortingLoc1);//Sort by popularity
    	Select sortByOrder = new Select(sorting1);
		sortByOrder.selectByVisibleText(sortingBy);
    }

	
    



	}


