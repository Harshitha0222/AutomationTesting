package com.cts.test;

import java.io.IOException;



import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cts.base.LaunchWebDriver;
import com.cts.pages.LogoutAccount;
import com.cts.pages.MyAccount;
import com.cts.pages.RegisterAccount;
//import com.cts.utils.ExcelUtils;



public class shopTest extends LaunchWebDriver {
	
	
//	@DataProvider
//	public String[][] practiceTest() throws IOException
//	{
//	String[][] data = ExcelUtils.getSheetIntoStringArray("resource/ExcelAutomation.xlsx",
//	"RegisterData");
//	return data;
//	}




	@Test(dataProvider = "practiceTest")
	public void placeOrderTest(String username, String password, String emailname,String loginpassword, String sortBy, String name) 
	{
	//Thread.sleep(1000);
		
//		MyAccountPage myaccount= new MyAccountPage();
//		myaccount.clickOnMyAccount();	
		MyAccount.MyAccount(driver);
		
	RegisterAccount.enterUsername(driver,username );
	RegisterAccount.enterPassword(driver,password);
	//Thread.sleep(1000);
	RegisterAccount.clickOnRegister(driver);

	LogoutAccount.clickOnLogOut(driver);
	

	RegisterAccount.enterEmail(driver, emailname);
	RegisterAccount.enterLoginPassword(driver, loginpassword);
	RegisterAccount.clickOnLogin(driver);
	
	LogoutAccount.ClicokOnshop(driver);
	LogoutAccount.clickOnHtmlBook(driver);
	LogoutAccount.sortBy(driver, sortBy);
	LogoutAccount.selectBook(driver);
	MyAccount.search(driver, name);
	//MyAccountPage.search(driver);
	MyAccount.displaytext(driver);
	
	
	




	}
	}


